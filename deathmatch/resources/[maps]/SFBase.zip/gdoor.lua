function createTheGate ()
myGate1 = createObject ( 2933, -134.60000610352, -1654.7999511719, 3.4000000953674, 0, 0, 0 )
end
addEventHandler ( "onResourceStart", getResourceRootElement ( getThisResource () ), createTheGate )
 
 
 
 
 
function openMyGate ( )
moveObject ( myGate1, 4500, -143.60000610352, -1654.7999511719, 3.4000000953674 )
end
addCommandHandler("baseon",openMyGate)
 
 
function movingMyGateBack ()
moveObject ( myGate1, 4500, -134.60000610352, -1654.7999511719, 3.4000000953674 )
end
addCommandHandler("baseoff",movingMyGateBack)
 
 
-- Web Site : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://youtube.com/c/SparroWMTA/

-- Discord : https://discord.gg/DzgEcvy