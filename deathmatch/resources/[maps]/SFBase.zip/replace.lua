function replaceModel()

txd_a51jdrx = engineLoadTXD ( "data/a51jdrx.txd" )
engineImportTXD ( txd_a51jdrx, 3095 )

end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)


-- Web Site : https://sparrow-mta.blogspot.com/

-- Facebook : https://facebook.com/sparrowgta/
-- İnstagram : https://instagram.com/sparrowmta/
-- YouTube : https://youtube.com/c/SparroWMTA/

-- Discord : https://discord.gg/DzgEcvy