local streamURL = "http://play.internet-radio-guide.net/pls.php?id=163195"
function onResourceStart()
	
sound = playSound3D(streamURL, -2043.5, 161.39999389648, 29.39999961853, true) 

end

addEventHandler("onClientResourceStart", getResourceRootElement(getThisResource()), onResourceStart)
